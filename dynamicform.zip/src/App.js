import React, { Component } from 'react'
import { createStore } from 'redux'
import { Provider } from 'react-redux'
import AppComponent from './components/AppComponent'
import mainReducer from './reducers'

const store = createStore(mainReducer);

class App extends Component {
  render() {
    return (
      <Provider store={store}>
        <AppComponent />
      </Provider>
      
    );
  }
}


export default App;
