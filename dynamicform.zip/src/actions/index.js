let nextTodoId = 0
export const addTodo = (text) => ({
  type: 'ADD_TODO',
  id: nextTodoId++,
  text
});

export const addElement = (type) => ({
	type:'ADD_ELEMENT',
	element_type:type
});

export const deleteStudent = (studentid) => ({
	type: 'DELETE_STUDENT',
	id: studentid
});

export const setVisibilityFilter = (filter) => ({
  type: 'SET_VISIBILITY_FILTER',
  filter
})

export const toggleTodo = (id) => ({
  type: 'TOGGLE_TODO',
  id
})
