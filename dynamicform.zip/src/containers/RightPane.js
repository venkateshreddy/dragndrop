import React from 'react'
import { connect } from 'react-redux'


class RightPane extends React.Component{
  render(){
    return (
      <div>
        {
          this.props.formelements.map ((element, index) => {
            return <span key={element.id}>{element.type}<br /></span>
          })
        }
      </div>
    )
  }        
}
function mapStateToProps(state) {
  return { 
    formelements: state.formReducer.formelements
  };
}

export default connect(mapStateToProps)(RightPane);
