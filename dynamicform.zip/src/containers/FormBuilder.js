import React from 'react';
import { connect } from 'react-redux';
import LeftPane from '../containers/LeftPane'
import RightPane from '../containers/RightPane'

class FormBuilder extends React.Component{
  render(){
    return (
      <div>
      	<LeftPane />
      	<RightPane />
      </div>
    );
   }
}
function mapStateToProps(state) {
  return { 
    formelements: state.formReducer.formelements
  };
}

export default connect(mapStateToProps)(FormBuilder);
