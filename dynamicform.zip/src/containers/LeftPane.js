import React from 'react'
import { connect } from 'react-redux'
import { addElement } from '../actions'


const LeftPane = ({ dispatch }) => {
  return (
    <div className="side_div">
      <ul className="static_ul">
        <li onClick={() => dispatch(addElement("TEXTBOX"))}>Text Box</li>
        <li onClick={() => dispatch(addElement("RADIO"))}>Boolean</li>
        <li onClick={() => dispatch(addElement("DROPDOWN"))}>dropdown</li>
      </ul>
    </div>
  )

}

export default connect()(LeftPane)

