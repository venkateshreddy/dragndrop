import { combineReducers } from 'redux'
import studentReducer from './studentreducer'
import formReducer from './formreducer'

const mainReducer = combineReducers({
  formReducer,
  studentReducer
  
})

export default mainReducer
