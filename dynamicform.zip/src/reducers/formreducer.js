const initialState = {
  formelements: [
        {id:1, order:1, type:"textbox", max_length:30, name:"name", display_text:"Name"},
        {id:2, order:2, type:"textbox", max_length:100, name:"email" , display_text:"Email"},
        {id:3, order:3, type:"radio", name:"gender", display_text:"Gender", values:[{label:"Male", selected:true}, {label:"Female", selected:false}]},
        {id:4, order:4, type:"dropdown", name:"qualification", display_text:"Qualification", options:[{label:"MCA", value:"MCA", selected:true}, {label:"Btech", value:"BTECH", selected:false}]},
        {id:5, order:5, type:"checkbox", checked:true, name:"tnc", display_text:"Accept Terms and Conditions"}
      ],
  current_id:5
};

function getElementObject(type){
  switch (type) {
    case "TEXTBOX": {
      return {id:null, order:null, type:"textbox", name:"some_name", display_text:"New Textbox", max_length:30};
    }
    case "RADIO": {
      return {type:"radio", name:"some_name", display_text:"New Radio button", values:[]};
    }
    case "DROPDOWN": {
      return {type:"dropdown", name:"some_name", display_text:"New Dropdown", options:[]};
    }
    default: {
      console.log("The option is not listed in the possibilities");
      return;
    }
  }
}

export default function formReducer(state = initialState, action) {
  let st = state;
  console.log("Before "+action.type, st);
  switch (action.type) {
    case 'REMOVE_ELEMENT': {
      var newFormElements = [];
      var element_order = 0
      for(var i=0; i<st.formelements.length; i++){
        var element = st.formelements[i];
        if(element.id === action.id){

        }else{
          element_order++;
          element.order = element_order
          newFormElements.push(element);
        } 
      }
      st = { ...state, formelements: newFormElements};
      break;
    }
    case 'ADD_ELEMENT': {
      newFormElements = st.formelements;
      var newElement = getElementObject(action.element_type);
      if(newElement){
        newElement.id = st.current_id+1;
        newElement.order = newFormElements.length + 1;
        newFormElements.push(newElement)
        st = { ...state, formelements: newFormElements, current_id:st.current_id+1};
      }
      break;
    }
    default: {
      return st;
    }
    
  }
  console.log("After "+action.type, st);
  return st;
}